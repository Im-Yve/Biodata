import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';

class FormPage extends StatefulWidget {
  const FormPage({super.key});

  @override
  State<FormPage> createState() => _FormPageState();
}

class _FormPageState extends State<FormPage> {
  final _formKey = GlobalKey<FormState>();

  // Personal Information
  final TextEditingController fullNameController = TextEditingController();
  final TextEditingController dobController = TextEditingController();
  final TextEditingController ageController = TextEditingController();
  final TextEditingController nationalityController = TextEditingController();
  final TextEditingController addressController = TextEditingController();
  final TextEditingController contactController = TextEditingController();
  final TextEditingController emailController = TextEditingController();

  String? selectedGender;
  String? selectedCivilStatus;

  // Educational Background
  final TextEditingController schoolsController = TextEditingController();
  final TextEditingController degreesController = TextEditingController();
  final TextEditingController yearsAttendedController = TextEditingController();
  final TextEditingController academicAchievementsController = TextEditingController();

  // Career / Employment History
  final TextEditingController jobsController = TextEditingController();
  final TextEditingController companiesController = TextEditingController();
  final TextEditingController jobTitlesController = TextEditingController();
  final TextEditingController employmentDatesController = TextEditingController();
  final TextEditingController responsibilitiesController = TextEditingController();

  final List<String> genderOptions = [
    'Male',
    'Female',
    'Non-binary',
    'Prefer not to say',
  ];

  final List<String> civilStatusOptions = [
    'Single',
    'Married',
    'Divorced',
    'Widowed',
    'Separated',
  ];

  final FirebaseFirestore firestore = FirebaseFirestore.instance;

  Future<void> saveData() async {
    if (!_formKey.currentState!.validate()) {
      _showSnackBar('Please fill in all required fields', isError: true);
      return;
    }

    if (selectedGender == null || selectedCivilStatus == null) {
      _showSnackBar('Please select gender and civil status', isError: true);
      return;
    }

    try {
      await firestore.collection('job_biodata').add({
        'personalInfo': {
          'fullName': fullNameController.text.trim(),
          'dob': dobController.text.trim(),
          'age': ageController.text.trim(),
          'gender': selectedGender,
          'nationality': nationalityController.text.trim(),
          'civilStatus': selectedCivilStatus,
          'address': addressController.text.trim(),
          'contact': contactController.text.trim(),
          'email': emailController.text.trim(),
        },
        'education': {
          'schools': schoolsController.text.trim(),
          'degrees': degreesController.text.trim(),
          'yearsAttended': yearsAttendedController.text.trim(),
          'academicAchievements': academicAchievementsController.text.trim(),
        },
        'employment': {
          'jobs': jobsController.text.trim(),
          'companies': companiesController.text.trim(),
          'jobTitles': jobTitlesController.text.trim(),
          'employmentDates': employmentDatesController.text.trim(),
          'responsibilities': responsibilitiesController.text.trim(),
        },
        'createdAt': FieldValue.serverTimestamp(),
      });

      _showSnackBar('Biodata saved successfully');
      _clearForm();
    } catch (e) {
      _showSnackBar('Error saving data: $e', isError: true);
    }
  }

  void _showSnackBar(String message, {bool isError = false}) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(message),
        backgroundColor: isError ? Colors.redAccent : const Color(0xFF1A1A2E),
        behavior: SnackBarBehavior.floating,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
        margin: const EdgeInsets.all(16),
      ),
    );
  }

  void _clearForm() {
    fullNameController.clear();
    dobController.clear();
    ageController.clear();
    nationalityController.clear();
    addressController.clear();
    contactController.clear();
    emailController.clear();
    schoolsController.clear();
    degreesController.clear();
    yearsAttendedController.clear();
    academicAchievementsController.clear();
    jobsController.clear();
    companiesController.clear();
    jobTitlesController.clear();
    employmentDatesController.clear();
    responsibilitiesController.clear();
    setState(() {
      selectedGender = null;
      selectedCivilStatus = null;
    });
  }

  @override
  void dispose() {
    fullNameController.dispose();
    dobController.dispose();
    ageController.dispose();
    nationalityController.dispose();
    addressController.dispose();
    contactController.dispose();
    emailController.dispose();
    schoolsController.dispose();
    degreesController.dispose();
    yearsAttendedController.dispose();
    academicAchievementsController.dispose();
    jobsController.dispose();
    companiesController.dispose();
    jobTitlesController.dispose();
    employmentDatesController.dispose();
    responsibilitiesController.dispose();
    super.dispose();
  }

  Widget _buildSectionHeader(String title, IconData icon) {
    return Padding(
      padding: const EdgeInsets.only(top: 32, bottom: 16),
      child: Row(
        children: [
          Container(
            padding: const EdgeInsets.all(10),
            decoration: BoxDecoration(
              color: const Color(0xFF1A1A2E).withOpacity(0.05),
              borderRadius: BorderRadius.circular(12),
            ),
            child: Icon(icon, size: 22, color: const Color(0xFF1A1A2E)),
          ),
          const SizedBox(width: 14),
          Text(
            title,
            style: const TextStyle(
              fontSize: 18,
              fontWeight: FontWeight.w700,
              color: Color(0xFF1A1A2E),
              letterSpacing: -0.3,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildTextField({
    required TextEditingController controller,
    required String label,
    String? hint,
    int maxLines = 1,
    TextInputType? keyboardType,
    String? Function(String?)? validator,
  }) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 16),
      child: TextFormField(
        controller: controller,
        maxLines: maxLines,
        keyboardType: keyboardType,
        validator: validator ?? (value) {
          if (value == null || value.trim().isEmpty) {
            return 'This field is required';
          }
          return null;
        },
        decoration: InputDecoration(
          labelText: label,
          hintText: hint,
          alignLabelWithHint: maxLines > 1,
        ),
      ),
    );
  }

  Widget _buildDropdown({
    required String label,
    required String? value,
    required List<String> items,
    required ValueChanged<String?> onChanged,
  }) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 16),
      child: DropdownButtonFormField<String>(
        value: value,
        decoration: InputDecoration(
          labelText: label,
        ),
        icon: const Icon(Icons.keyboard_arrow_down_rounded),
        items: items
            .map(
              (item) => DropdownMenuItem<String>(
                value: item,
                child: Text(item),
              ),
            )
            .toList(),
        onChanged: onChanged,
        validator: (val) {
          if (val == null || val.isEmpty) {
            return 'Please select an option';
          }
          return null;
        },
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Job Biodata'),
      ),
      body: Form(
        key: _formKey,
        child: SingleChildScrollView(
          padding: const EdgeInsets.fromLTRB(20, 8, 20, 40),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // Header Card
              Container(
                width: double.infinity,
                padding: const EdgeInsets.all(24),
                decoration: BoxDecoration(
                  gradient: const LinearGradient(
                    colors: [Color(0xFF1A1A2E), Color(0xFF16213E)],
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                  ),
                  borderRadius: BorderRadius.circular(20),
                  boxShadow: [
                    BoxShadow(
                      color: const Color(0xFF1A1A2E).withOpacity(0.2),
                      blurRadius: 20,
                      offset: const Offset(0, 8),
                    ),
                  ],
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Icon(
                      Icons.person_outline_rounded,
                      color: Colors.white70,
                      size: 32,
                    ),
                    const SizedBox(height: 16),
                    const Text(
                      'Personal Details',
                      style: TextStyle(
                        color: Colors.white,
                        fontSize: 22,
                        fontWeight: FontWeight.w700,
                        letterSpacing: -0.5,
                      ),
                    ),
                    const SizedBox(height: 6),
                    Text(
                      'Fill in your information accurately',
                      style: TextStyle(
                        color: Colors.white.withOpacity(0.7),
                        fontSize: 14,
                      ),
                    ),
                  ],
                ),
              ),

              // Personal Information
              _buildSectionHeader('Personal Information', Icons.person_outline_rounded),

              _buildTextField(
                controller: fullNameController,
                label: 'Full Name',
                hint: 'Enter your full name',
              ),
              Row(
                children: [
                  Expanded(
                    child: _buildTextField(
                      controller: dobController,
                      label: 'Date of Birth',
                      hint: 'MM/DD/YYYY',
                      keyboardType: TextInputType.datetime,
                    ),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: _buildTextField(
                      controller: ageController,
                      label: 'Age',
                      hint: 'e.g., 28',
                      keyboardType: TextInputType.number,
                      validator: (value) {
                        if (value == null || value.trim().isEmpty) {
                          return 'Required';
                        }
                        final age = int.tryParse(value.trim());
                        if (age == null || age < 1 || age > 120) {
                          return 'Invalid age';
                        }
                        return null;
                      },
                    ),
                  ),
                ],
              ),
              _buildDropdown(
                label: 'Gender',
                value: selectedGender,
                items: genderOptions,
                onChanged: (val) => setState(() => selectedGender = val),
              ),
              _buildTextField(
                controller: nationalityController,
                label: 'Nationality',
                hint: 'e.g., Filipino',
              ),
              _buildDropdown(
                label: 'Civil Status',
                value: selectedCivilStatus,
                items: civilStatusOptions,
                onChanged: (val) => setState(() => selectedCivilStatus = val),
              ),
              _buildTextField(
                controller: addressController,
                label: 'Address',
                hint: 'Enter your complete address',
                maxLines: 2,
              ),
              _buildTextField(
                controller: contactController,
                label: 'Contact Number',
                hint: 'e.g., +63 912 345 6789',
                keyboardType: TextInputType.phone,
              ),
              _buildTextField(
                controller: emailController,
                label: 'Email',
                hint: 'e.g., you@example.com',
                keyboardType: TextInputType.emailAddress,
                validator: (value) {
                  if (value == null || value.trim().isEmpty) {
                    return 'Email is required';
                  }
                  if (!RegExp(r'^[^@]+@[^@]+\.[^@]+').hasMatch(value.trim())) {
                    return 'Enter a valid email address';
                  }
                  return null;
                },
              ),

              // Educational Background
              _buildSectionHeader('Educational Background', Icons.school_outlined),

              _buildTextField(
                controller: schoolsController,
                label: 'Schools / Colleges Attended',
                hint: 'List the schools you attended',
                maxLines: 2,
              ),
              _buildTextField(
                controller: degreesController,
                label: 'Degrees or Qualifications',
                hint: 'e.g., BS Computer Science',
                maxLines: 2,
              ),
              _buildTextField(
                controller: yearsAttendedController,
                label: 'Years Attended or Graduation Dates',
                hint: 'e.g., 2015 - 2019',
              ),
              _buildTextField(
                controller: academicAchievementsController,
                label: 'Academic Achievements (if relevant)',
                hint: 'e.g., Cum Laude, Dean\'s Lister',
                maxLines: 3,
              ),

              // Career / Employment History
              _buildSectionHeader('Employment History', Icons.work_outline_rounded),

              _buildTextField(
                controller: jobsController,
                label: 'Current or Previous Jobs',
                hint: 'List your job positions',
                maxLines: 2,
              ),
              _buildTextField(
                controller: companiesController,
                label: 'Company / Organization Names',
                hint: 'List the companies you worked for',
                maxLines: 2,
              ),
              _buildTextField(
                controller: jobTitlesController,
                label: 'Job Titles',
                hint: 'e.g., Software Engineer',
                maxLines: 2,
              ),
              _buildTextField(
                controller: employmentDatesController,
                label: 'Dates of Employment',
                hint: 'e.g., Jan 2020 - Present',
              ),
              _buildTextField(
                controller: responsibilitiesController,
                label: 'Major Responsibilities or Achievements',
                hint: 'Describe your key responsibilities',
                maxLines: 4,
              ),

              const SizedBox(height: 32),

              // Save Button
              SizedBox(
                width: double.infinity,
                child: ElevatedButton(
                  onPressed: saveData,
                  child: const Text('Save to Firebase'),
                ),
              ),

              const SizedBox(height: 12),

              // Clear Button
              SizedBox(
                width: double.infinity,
                child: TextButton(
                  onPressed: _clearForm,
                  style: TextButton.styleFrom(
                    foregroundColor: Colors.grey.shade600,
                    minimumSize: const Size.fromHeight(48),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(12),
                    ),
                  ),
                  child: const Text(
                    'Clear All Fields',
                    style: TextStyle(
                      fontSize: 15,
                      fontWeight: FontWeight.w500,
                    ),
                  ),
                ),
              ),

              const SizedBox(height: 20),
            ],
          ),
        ),
      ),
    );
  }
}